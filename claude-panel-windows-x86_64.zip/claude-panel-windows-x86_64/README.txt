Claude Code Local Panel
=========================

1. Mueve esta carpeta donde quieras tenerla (Escritorio, Documentos, …).

2. Doble-clic en  claude-panel.exe
   - La primera vez tardará 30-60 s descargando ClickHouse local (~150 MB).
   - El panel se queda en tu equipo: NO envía datos a ningún sitio.

3. Se abrirá tu navegador en http://127.0.0.1:8765

4. Si aún no usas Claude Code, verás una pantalla de bienvenida. Empieza a
   conversar con Claude Code en tu terminal y pulsa "Volver a buscar".

NOTAS POR SISTEMA OPERATIVO
---------------------------

Linux:
  Si el doble-clic no funciona, abre un terminal en esta carpeta y ejecuta:
      ./claude-panel
  El binario y los logs viven en:
      ~/.local/share/claude-panel/

macOS:
  La primera vez, macOS puede mostrar "no se puede abrir porque proviene
  de un desarrollador no identificado". Solución:
      Botón derecho sobre claude-panel → Abrir → Confirmar Abrir.
  Sólo hace falta hacerlo la primera vez.
  Logs y caché en:
      ~/Library/Application Support/ClaudeCodePanel/

Windows:
  REQUIERE WSL (Windows Subsystem for Linux), porque ClickHouse no tiene
  binario nativo para Windows. Instalación de WSL (una sola vez):
      1. Abre PowerShell como Administrador.
      2. Ejecuta:   wsl --install
      3. Reinicia el equipo.
      4. Vuelve a doble-clic en claude-panel.exe
  Si no tienes WSL, el panel te lo dirá con un diálogo amigable.
  Logs y caché en:
      %LOCALAPPDATA%\ClaudeCodePanel\

DATOS QUE LEE EL PANEL
----------------------
El panel lee — en sólo-lectura — las sesiones de Claude Code:
  Linux/macOS: ~/.claude/projects/
  Windows:     %USERPROFILE%\.claude\projects\
